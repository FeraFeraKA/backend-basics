import z from "zod";
import { ORDER_OPTIONS, SORT_OPTIONS, TASK_STATUSES } from "./tasks.types.js";

export const createTaskSchema = z.object({
  title: z
    .string()
    .min(1, "Title is required")
    .max(120, "Title must be shorter than 120 characters"),
  text: z.string().max(2000, "Text must be shorter than 2000 characters"),
  status: z.enum([...TASK_STATUSES]),
});

export const updateTaskSchema = createTaskSchema.partial();

export const tasksListQuerySchema = z.object({
  page: z.number(),
  limit: z.number(),
  status: z.enum([...TASK_STATUSES]).optional(),
  search: z.string().optional(),
  sort: z.enum([...SORT_OPTIONS]),
  order: z.enum([...ORDER_OPTIONS]),
});

export type TasksListQuery = z.infer<typeof tasksListQuerySchema>;
